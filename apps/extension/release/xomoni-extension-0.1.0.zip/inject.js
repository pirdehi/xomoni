"use strict";
(() => {
  // src/shared/bridge.ts
  var PORT_EVENT = "xomoni:port";
  var ASK_EVENT = "xomoni:ask";
  function takePort(doc, onPort) {
    const take = (event) => {
      const port = event.ports?.[0];
      if (!port) return;
      event.preventDefault();
      doc.removeEventListener(PORT_EVENT, take);
      onPort(port);
    };
    doc.addEventListener(PORT_EVENT, take);
    doc.dispatchEvent(new Event(ASK_EVENT));
  }

  // src/shared/x-operations.ts
  var TIMELINE_OPS = /* @__PURE__ */ new Set([
    "UserTweets",
    "UserTweetsAndReplies",
    "Likes",
    "SearchTimeline",
    "TweetDetail"
  ]);
  var MUTATION_OPS = /* @__PURE__ */ new Set([
    "DeleteTweet",
    "DeleteRetweet",
    "FavoriteTweet",
    "UnfavoriteTweet"
  ]);
  var PROFILE_OPS = /* @__PURE__ */ new Set(["UserByScreenName"]);
  var WATCHED_OPS = /* @__PURE__ */ new Set([...TIMELINE_OPS, ...MUTATION_OPS, ...PROFILE_OPS]);

  // src/inject/interceptor.ts
  (() => {
    const w = window;
    if (w.__xomoniNet) return;
    w.__xomoniNet = true;
    const OP = /\/i\/api\/graphql\/[^/?]+\/([A-Za-z]+)/;
    const WATCHED = WATCHED_OPS;
    const CAPTURED_HEADERS = ["x-rate-limit-limit", "x-rate-limit-remaining", "x-rate-limit-reset", "date"];
    let port = null;
    takePort(document, (p) => port = p);
    const emit = (capture) => port?.postMessage(capture);
    const watchedOp = (url) => {
      const op = url.match(OP)?.[1];
      return op && WATCHED.has(op) ? op : null;
    };
    const nativeFetch = window.fetch;
    window.fetch = function(input, init) {
      let op = null;
      let url = "";
      let reqBody = Promise.resolve(null);
      try {
        url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
        op = watchedOp(url);
        if (op && typeof init?.body === "string") reqBody = Promise.resolve(init.body);
        else if (op && init?.body == null && input instanceof Request)
          reqBody = input.clone().text().catch(() => null);
      } catch {
      }
      const pending = nativeFetch.call(window, input, init);
      try {
        if (op) {
          const watched = op;
          const method = (init?.method ?? (input instanceof Request ? input.method : "GET")).toUpperCase();
          pending.then(
            (res) => {
              const headers = Object.fromEntries(CAPTURED_HEADERS.map((h) => [h, res.headers.get(h)]));
              Promise.all([reqBody, res.clone().text()]).then(
                ([req, body]) => emit({ op: watched, url, method, status: res.status, reqBody: req, headers, body })
              ).catch(() => {
              });
            },
            () => reqBody.then((req) => emit({ op: watched, url, method, status: 0, reqBody: req, headers: {}, body: "" }))
          );
        }
      } catch {
      }
      return pending;
    };
    const nativeOpen = XMLHttpRequest.prototype.open;
    const nativeSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url, ...rest) {
      this.__xomoni = { method: String(method).toUpperCase(), url: String(url) };
      nativeOpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function(body) {
      try {
        const meta = this.__xomoni;
        const op = meta ? watchedOp(meta.url) : null;
        if (meta && op) {
          const reqBody = typeof body === "string" ? body : null;
          this.addEventListener("loadend", () => {
            let text = "";
            try {
              text = this.responseType === "" || this.responseType === "text" ? this.responseText : JSON.stringify(this.response);
            } catch {
            }
            const headers = {};
            for (const h of CAPTURED_HEADERS) headers[h] = this.getResponseHeader(h);
            emit({ op, url: meta.url, method: meta.method, status: this.status, reqBody, headers, body: text });
          });
        }
      } catch {
      }
      nativeSend.call(this, body);
    };
  })();
})();
