"use strict";
(() => {
  // src/shared/bridge.ts
  var PORT_EVENT = "xomoni:port";
  var ASK_EVENT = "xomoni:ask";
  function offerPort(doc, port) {
    const offer = () => !doc.dispatchEvent(new MessageEvent(PORT_EVENT, { ports: [port], cancelable: true }));
    if (!offer()) doc.addEventListener(ASK_EVENT, offer, { once: true });
  }
  function isCapture(data) {
    if (!data || typeof data !== "object") return false;
    const c = data;
    return typeof c.op === "string" && typeof c.url === "string" && typeof c.method === "string" && typeof c.status === "number" && (c.reqBody === null || typeof c.reqBody === "string") && !!c.headers && typeof c.headers === "object" && Object.values(c.headers).every((v) => v === null || typeof v === "string") && typeof c.body === "string";
  }

  // src/shared/json.ts
  function asObject(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value) ? value : void 0;
  }
  function asArray(value) {
    return Array.isArray(value) ? value : [];
  }
  function asString(value) {
    return typeof value === "string" ? value : void 0;
  }
  function asNumber(value) {
    const n = typeof value === "string" && value.trim() !== "" ? Number(value) : value;
    return typeof n === "number" && Number.isFinite(n) ? n : void 0;
  }
  function asId(value) {
    if (typeof value === "string") return value || void 0;
    return typeof value === "number" && Number.isInteger(value) ? String(value) : void 0;
  }
  function at(value, ...path) {
    let current = value;
    for (const key of path) current = asObject(current)?.[key];
    return current;
  }

  // src/shared/attention.ts
  var isLoginPath = (path) => path === "/login" || path.startsWith("/i/flow/login") || path.startsWith("/i/jf/");
  var isCheckPath = (path) => path.startsWith("/account/") || path.startsWith("/i/flow/") && !isLoginPath(path);
  var RESTRICTION_PHRASES = [
    "your account is suspended",
    "account has been suspended",
    "account is temporarily limited",
    "features are temporarily limited",
    "temporarily restricted",
    "your account is restricted",
    "read-only mode"
  ];
  function restrictionNotice(text) {
    for (const line of text.split(/\n+/)) {
      const lower = line.toLowerCase();
      if (RESTRICTION_PHRASES.some((p) => lower.includes(p))) return line.trim().slice(0, 200);
    }
    return null;
  }

  // src/shared/time.ts
  var TWITTER_EPOCH = 1288834974657n;
  var MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  function snowflakeTime(id) {
    if (!/^\d{15,20}$/.test(id)) return null;
    const ms = Number((BigInt(id) >> 22n) + TWITTER_EPOCH);
    return ms > 1288834974657 && ms < Date.now() + 864e5 ? ms : null;
  }
  function parseTwitterDate(value) {
    if (typeof value !== "string") return null;
    const m = value.match(/^\w{3} (\w{3}) (\d{1,2}) (\d{2}):(\d{2}):(\d{2}) ([+-])(\d{2})(\d{2}) (\d{4})$/);
    if (!m) {
      const t = Date.parse(value);
      return Number.isNaN(t) ? null : t;
    }
    const month = MONTHS.indexOf(m[1] ?? "");
    if (month < 0) return null;
    const offset = (m[6] === "-" ? -1 : 1) * (Number(m[7]) * 60 + Number(m[8])) * 6e4;
    return Date.UTC(Number(m[9]), month, Number(m[2]), Number(m[3]), Number(m[4]), Number(m[5])) - offset;
  }
  function estimateLikedAt(sortIndex, postId, postCreatedAt) {
    if (!sortIndex || sortIndex === postId) return null;
    const t = snowflakeTime(sortIndex);
    if (t == null) return null;
    if (t < postCreatedAt - 6e4 || t > Date.now() + 6e4) return null;
    return t;
  }

  // src/shared/x-operations.ts
  var TIMELINE_OPS = /* @__PURE__ */ new Set([
    "UserTweets",
    "UserTweetsAndReplies",
    "Likes",
    "SearchTimeline",
    "TweetDetail"
  ]);
  var MUTATION_OPS = /* @__PURE__ */ new Set([
    "DeleteTweet",
    "DeleteRetweet",
    "FavoriteTweet",
    "UnfavoriteTweet"
  ]);
  var PROFILE_OPS = /* @__PURE__ */ new Set(["UserByScreenName"]);
  var WATCHED_OPS = /* @__PURE__ */ new Set([...TIMELINE_OPS, ...MUTATION_OPS, ...PROFILE_OPS]);

  // src/shared/graphql.ts
  function parseVariables(url, body) {
    try {
      if (body) {
        const variables = asObject(at(JSON.parse(body), "variables"));
        if (variables) return variables;
      }
      const raw = new URL(url, "https://x.com").searchParams.get("variables");
      return raw && asObject(JSON.parse(raw)) || {};
    } catch {
      return {};
    }
  }
  function extractErrors(json) {
    return asArray(at(json, "errors")).map((e) => ({
      code: asNumber(at(e, "code") ?? at(e, "extensions", "code")) ?? null,
      message: asString(at(e, "message")) ?? ""
    }));
  }
  function unwrap(result) {
    const r = asObject(result);
    if (!r) return null;
    const inner = asObject(r.tweet);
    if (r.__typename === "TweetWithVisibilityResults" && inner) return inner;
    if (!r.legacy && inner?.legacy) return inner;
    return r.legacy ? r : null;
  }
  function parseTweet(result, sortIndex) {
    const t = unwrap(result);
    const legacy = asObject(t?.legacy);
    if (!t || !legacy) return null;
    const id = asString(t.rest_id) ?? asString(legacy.id_str);
    if (!id) return null;
    const user = at(t, "core", "user_results", "result");
    const sourceResult = at(legacy, "retweeted_status_result", "result");
    const favorited = legacy.favorited;
    return {
      id,
      authorId: asString(legacy.user_id_str) ?? asString(at(user, "rest_id")) ?? "",
      authorHandle: asString(at(user, "core", "screen_name")) ?? asString(at(user, "legacy", "screen_name")) ?? "",
      createdAt: parseTwitterDate(legacy.created_at) ?? snowflakeTime(id) ?? 0,
      text: asString(at(t, "note_tweet", "note_tweet_results", "result", "text")) ?? asString(legacy.full_text) ?? "",
      inReplyToId: asString(legacy.in_reply_to_status_id_str) ?? null,
      inReplyToUserId: asString(legacy.in_reply_to_user_id_str) ?? null,
      likes: asNumber(legacy.favorite_count) ?? 0,
      reposts: asNumber(legacy.retweet_count) ?? 0,
      replies: asNumber(legacy.reply_count) ?? 0,
      favorited: typeof favorited === "boolean" ? favorited : null,
      source: sourceResult ? parseTweet(sourceResult, null) : null,
      sortIndex
    };
  }
  function extractTweets(json) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    const walk = (node, sortIndex, depth) => {
      if (depth > 60) return;
      if (Array.isArray(node)) {
        for (const child of asArray(node)) walk(child, sortIndex, depth + 1);
        return;
      }
      const obj = asObject(node);
      if (!obj) return;
      const entrySortIndex = asString(obj.sortIndex);
      if (typeof obj.entryId === "string" && entrySortIndex !== void 0) sortIndex = entrySortIndex;
      const results = asObject(obj.tweet_results);
      if (results) {
        const tweet = parseTweet(results.result, sortIndex);
        if (tweet && !seen.has(tweet.id)) {
          seen.add(tweet.id);
          out.push(tweet);
        }
        return;
      }
      for (const value of Object.values(obj)) walk(value, sortIndex, depth + 1);
    };
    walk(json, null, 0);
    return out;
  }
  var UNAVAILABLE_TYPES = /* @__PURE__ */ new Set(["TweetTombstone", "TweetUnavailable"]);
  function unavailableTweetIds(json) {
    const out = /* @__PURE__ */ new Set();
    const walk = (node, entryTweetId, depth) => {
      if (depth > 60) return;
      if (Array.isArray(node)) {
        for (const child of asArray(node)) walk(child, entryTweetId, depth + 1);
        return;
      }
      const obj = asObject(node);
      if (!obj) return;
      const entry = /^tweet-(\d+)$/.exec(asString(obj.entryId) ?? "")?.[1] ?? entryTweetId;
      const results = asObject(obj.tweet_results);
      if (results) {
        const type = asString(at(results, "result", "__typename"));
        const id = asString(at(results, "result", "rest_id")) ?? entry;
        if (type && UNAVAILABLE_TYPES.has(type) && id) out.add(id);
        return;
      }
      for (const value of Object.values(obj)) walk(value, entry, depth + 1);
    };
    walk(json, void 0, 0);
    return [...out];
  }
  function extractProfile(json) {
    const u = asObject(at(json, "data", "user", "result"));
    const id = asString(u?.rest_id);
    if (!u || !id) return null;
    const legacy = asObject(u.legacy) ?? {};
    return {
      id,
      handle: asString(at(u, "core", "screen_name")) ?? asString(legacy.screen_name) ?? "",
      name: asString(at(u, "core", "name")) ?? asString(legacy.name) ?? "",
      avatar: asString(at(u, "avatar", "image_url")) ?? asString(legacy.profile_image_url_https) ?? "",
      postsCount: asNumber(legacy.statuses_count) ?? null,
      likesCount: asNumber(legacy.favourites_count) ?? null,
      followers: asNumber(legacy.followers_count) ?? null,
      following: asNumber(legacy.friends_count) ?? null,
      createdAt: parseTwitterDate(at(u, "core", "created_at") ?? legacy.created_at),
      verified: typeof u.is_blue_verified === "boolean" ? u.is_blue_verified : null
    };
  }
  function draftsFromTimeline(op, tweets, viewerId, variables) {
    if (op === "Likes") {
      if (asId(variables.userId) !== viewerId) return [];
      const drafts2 = tweets.filter((t) => t.favorited !== false).map((t) => likeDraft(t, estimateLikedAt(t.sortIndex, t.id, t.createdAt)));
      for (let i = 1; i < drafts2.length; i++) {
        const prev = drafts2[i - 1]?.likedAt;
        const cur = drafts2[i]?.likedAt;
        if (prev == null || cur == null || cur > prev) {
          drafts2.forEach((d) => d.likedAt = null);
          break;
        }
      }
      return drafts2;
    }
    const drafts = [];
    for (const t of tweets) {
      if (t.authorId !== viewerId) continue;
      if (t.source) {
        drafts.push({
          kind: "repost",
          id: t.id,
          targetId: t.source.id,
          createdAt: t.createdAt,
          likedAt: null,
          text: t.source.text,
          author: t.source.authorHandle,
          inReplyToId: null,
          selfReply: false,
          likes: t.source.likes,
          reposts: t.source.reposts,
          replies: t.source.replies
        });
        continue;
      }
      drafts.push({
        kind: t.inReplyToId ? "reply" : "post",
        id: t.id,
        targetId: t.id,
        createdAt: t.createdAt,
        likedAt: null,
        text: t.text,
        author: t.authorHandle,
        inReplyToId: t.inReplyToId,
        selfReply: !!t.inReplyToId && t.inReplyToUserId === viewerId,
        likes: t.likes,
        reposts: t.reposts,
        replies: t.replies
      });
    }
    return drafts;
  }
  function likeDraft(t, likedAt) {
    return {
      kind: "like",
      id: t.id,
      targetId: t.id,
      createdAt: t.createdAt,
      likedAt,
      text: t.text,
      author: t.authorHandle,
      inReplyToId: t.inReplyToId,
      selfReply: false,
      likes: t.likes,
      reposts: t.reposts,
      replies: t.replies
    };
  }

  // src/content/dom.ts
  var SEL = {
    article: 'article[data-testid="tweet"]',
    /** The "…" (More) button on a post, which opens the post menu. */
    caret: '[data-testid="caret"]',
    menu: '[role="menu"]',
    menuItem: '[role="menu"] [role="menuitem"]',
    /** The confirm button of X's "Delete post?" sheet. */
    confirm: '[data-testid="confirmationSheetConfirm"]',
    like: '[data-testid="like"]',
    unlike: '[data-testid="unlike"]',
    retweet: '[data-testid="retweet"]',
    unretweet: '[data-testid="unretweet"]',
    /** The "Undo repost" item in the menu that `unretweet` opens. */
    unretweetConfirm: '[data-testid="unretweetConfirm"]',
    /** X's placeholder for a timeline or search with no results. */
    empty: '[data-testid="emptyState"]',
    /** X's error panel, shown in place of content that failed to load. */
    errorDetail: '[data-testid="error-detail"]',
    /** The sidebar Profile link; its `href` is `/<handle>` of the signed-in user. */
    profileLink: 'a[data-testid="AppTabBar_Profile_Link"]',
    /** The overlay behind an open menu or sheet; clicking it closes them. */
    mask: '[data-testid="mask"]',
    /**
     * A pop-up over the page: X renders its modals and sheets in `#layers`; a modal elsewhere says so with
     * `aria-modal`. Menus (`role="menu"`) are not included.
     */
    dialog: '#layers [role="dialog"], #layers [role="alertdialog"], [aria-modal="true"]',
    /** A pop-up's own close button: the "×" in the header of X's modals, or a button labeled Close. */
    dialogClose: '[data-testid="app-bar-close"], [aria-label="Close"]'
  };
  var DELETE_LABELS = /* @__PURE__ */ new Set([
    "delete",
    "\u062D\u0630\u0641",
    "l\xF6schen",
    "supprimer",
    "eliminar",
    "elimina",
    "excluir",
    "apagar",
    "sil",
    "\u0443\u0434\u0430\u043B\u0438\u0442\u044C",
    "\u0432\u0438\u0434\u0430\u043B\u0438\u0442\u0438",
    "\u524A\u9664",
    "\uC0AD\uC81C",
    "\u5220\u9664",
    "\u522A\u9664",
    "verwijderen",
    "usu\u0144",
    "hapus",
    "\u0939\u091F\u093E\u090F\u0902",
    "\u0939\u091F\u093E\u090F\u0901",
    "\u05DE\u05D7\u05E7",
    "\u0E25\u0E1A",
    "x\xF3a"
  ]);
  var DANGER_RGB = "rgb(244, 33, 46)";
  var $ = (sel, root = document) => root.querySelector(sel);
  var $$ = (sel, root = document) => [
    ...root.querySelectorAll(sel)
  ];
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var jitter = (min, max) => min + Math.random() * (max - min);
  function articleInfo(article) {
    for (const time of $$("time", article)) {
      const link = time.parentElement;
      if (link?.tagName !== "A") continue;
      const [, handle, id] = (link.getAttribute("href") ?? "").match(/^\/([^/]+)\/status\/(\d+)/) ?? [];
      if (!handle || !id) continue;
      const t = Date.parse(time.getAttribute("datetime") ?? "");
      return { handle, id, time: Number.isNaN(t) ? null : t };
    }
    return null;
  }
  function findArticle(id) {
    return $$(SEL.article).find((a) => articleInfo(a)?.id === id) ?? null;
  }
  function findDeleteMenuItem() {
    const items = $$(SEL.menuItem);
    return items.find((el) => DELETE_LABELS.has(el.textContent.trim().toLowerCase())) ?? items.find((el) => getComputedStyle($("span", el) ?? el).color === DANGER_RGB) ?? null;
  }
  function click(el) {
    el.click();
  }
  function closeMenus() {
    const mask = $(SEL.mask);
    if (mask) click(mask);
    document.body.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true })
    );
  }
  function waitFor(probe, timeoutMs) {
    return new Promise((resolve) => {
      const first = probe();
      if (first) {
        resolve(first);
        return;
      }
      let done = false;
      const finish = (value) => {
        if (done) return;
        done = true;
        observer.disconnect();
        clearTimeout(timer);
        clearInterval(poll);
        resolve(value);
      };
      const check = () => {
        const v = probe();
        if (v) finish(v);
      };
      const observer = new MutationObserver(check);
      observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["data-testid", "href"]
      });
      const poll = setInterval(check, 500);
      const timer = setTimeout(() => finish(null), timeoutMs);
    });
  }
  function viewerIdFromCookie() {
    const twid = document.cookie.split("; ").find((c) => c.startsWith("twid="));
    if (!twid) return null;
    return decodeURIComponent(twid.slice(5)).match(/u=(\d+)/)?.[1] ?? null;
  }
  function noticeText() {
    const alerts = $$('[role="alert"]').map((el) => el.innerText);
    const dialogs = $$(SEL.dialog).map((el) => el.innerText.slice(0, 1500));
    const column = $('[data-testid="primaryColumn"]')?.innerText.slice(0, 1500) ?? "";
    return [...alerts, ...dialogs, column].join("\n");
  }
  function openDialog() {
    return $(SEL.dialog);
  }
  function describeDialog(dialog) {
    const label = dialog.getAttribute("aria-label");
    const firstLine = dialog.innerText.trim().split(/\n+/)[0] ?? "";
    return (label || firstLine || "a pop-up").slice(0, 80);
  }
  function viewerHandle() {
    return $(SEL.profileLink)?.getAttribute("href")?.replace(/^\//, "") || null;
  }

  // src/content/net.ts
  var waiters = /* @__PURE__ */ new Set();
  var timelineStatus = null;
  function lastTimelineStatus() {
    return timelineStatus;
  }
  function send(message) {
    try {
      chrome.runtime.sendMessage(message).catch(() => {
      });
    } catch {
    }
  }
  function waitForNet(ops, match, timeoutMs = 15e3) {
    return new Promise((resolve) => {
      const waiter = {
        ops,
        match,
        resolve: (ev) => {
          clearTimeout(timer);
          waiters.delete(waiter);
          resolve(ev);
        }
      };
      const timer = setTimeout(() => waiter.resolve(null), timeoutMs);
      waiters.add(waiter);
    });
  }
  function rateNumber(v) {
    if (v == null || v === "") return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }
  function resetAtFrom(headers, receivedAt = Date.now()) {
    const reset = rateNumber(headers["x-rate-limit-reset"]);
    if (reset == null) return null;
    return reset * 1e3 + Math.max(0, clockAhead(headers.date, receivedAt));
  }
  function clockAhead(date, receivedAt) {
    const xNow = date ? Date.parse(date) : NaN;
    return Number.isFinite(xNow) ? receivedAt - xNow : 0;
  }
  var unavailable = /* @__PURE__ */ new Set();
  var MAX_UNAVAILABLE = 1e3;
  function rememberUnavailable(id) {
    unavailable.delete(id);
    unavailable.add(id);
    if (unavailable.size > MAX_UNAVAILABLE) {
      const oldest = unavailable.values().next().value;
      if (oldest !== void 0) unavailable.delete(oldest);
    }
  }
  function isUnavailable(id) {
    return unavailable.has(id);
  }
  function handleCapture(raw) {
    let json = null;
    try {
      json = raw.body ? JSON.parse(raw.body) : null;
    } catch {
    }
    const ev = {
      op: raw.op,
      status: raw.status,
      headers: raw.headers,
      variables: parseVariables(raw.url, raw.reqBody),
      json,
      at: Date.now()
    };
    if (TIMELINE_OPS.has(ev.op)) {
      timelineStatus = ev.status;
      if (ev.status < 400) for (const id of unavailableTweetIds(json)) rememberUnavailable(id);
    }
    if (MUTATION_OPS.has(ev.op)) {
      for (const w of [...waiters]) if (w.ops.includes(ev.op) && w.match(ev.variables)) w.resolve(ev);
    }
    const viewerId = viewerIdFromCookie();
    if (!viewerId) return;
    const limit = rateNumber(ev.headers["x-rate-limit-limit"]);
    const remaining = rateNumber(ev.headers["x-rate-limit-remaining"]);
    if (limit != null || remaining != null || ev.status === 429) {
      send({
        type: "rate",
        obs: {
          key: `${viewerId}:${ev.op}`,
          accountId: viewerId,
          op: ev.op,
          limit,
          remaining,
          reset: resetAtFrom(ev.headers, ev.at),
          status: ev.status,
          at: ev.at
        }
      });
    }
    if (ev.status >= 400 || !json?.data) return;
    if (TIMELINE_OPS.has(ev.op)) {
      const drafts = draftsFromTimeline(ev.op, extractTweets(json), viewerId, ev.variables);
      if (drafts.length)
        send({ type: "ingest", accountId: viewerId, handle: viewerHandle(), op: ev.op, drafts, observedAt: ev.at });
    } else if (PROFILE_OPS.has(ev.op)) {
      const profile = extractProfile(json);
      if (profile?.id === viewerId) send({ type: "profile", profile });
    }
  }

  // src/content/actor.ts
  var bootId = Math.random().toString(36).slice(2);
  async function runCommand(command) {
    switch (command.cmd) {
      case "ping":
        return pageInfo();
      case "waitContent":
        return waitContent(command.timeoutMs);
      case "visible":
        return visibleTweets();
      case "scroll":
        return scrollMore();
      case "delete":
        return guarded(() => deletePost(command.id));
      case "unlike":
        return guarded(() => unlike(command.id));
      case "relikeUnlike":
        return guarded(() => relikeUnlike(command.id));
      case "unretweet":
        return guarded(() => unretweet(command.id));
      case "canary":
        return canary(command.action, command.id);
      case "clearPage":
        return clearPage();
    }
  }
  function pageInfo() {
    const path = location.pathname;
    const viewerId = viewerIdFromCookie();
    return {
      bootId,
      url: location.href,
      path,
      viewerId,
      handle: viewerHandle(),
      loggedIn: !!viewerId && !isLoginPath(path),
      locked: path.startsWith("/account/access"),
      challenge: isCheckPath(path),
      restriction: restrictionNotice(noticeText()),
      obstructed: !!openDialog(),
      lang: document.documentElement.lang || "",
      hidden: document.hidden
    };
  }
  async function guarded(action) {
    const info = pageInfo();
    if (info.locked) return { outcome: "locked", message: "X is asking you to unlock the account" };
    if (info.restriction) return { outcome: "restricted", message: `X shows: ${info.restriction}` };
    if (!info.loggedIn) return { outcome: "logged_out", message: "Not logged in to X in the worker window" };
    try {
      return await action();
    } catch (err) {
      closeMenus();
      return { outcome: "failed", message: err instanceof Error ? err.message : String(err) };
    }
  }
  var UNAVAILABLE = {
    outcome: "not_found",
    unavailable: true,
    message: "The original post is unavailable on X (deleted, or its account is suspended or protected)"
  };
  var orUnavailable = (id, result) => isUnavailable(id) ? UNAVAILABLE : result;
  async function waitContent(timeoutMs) {
    const kind = await waitFor(() => {
      if ($(SEL.article)) return "tweets";
      if ($(SEL.empty)) return "empty";
      if ($(SEL.errorDetail)) return "error";
      return null;
    }, timeoutMs);
    if (kind === "tweets") await sleep(400);
    const focal = /\/status\/(\d+)/.exec(location.pathname)?.[1];
    return {
      kind: kind ?? "timeout",
      count: $$(SEL.article).length,
      http: lastTimelineStatus(),
      unavailable: !!focal && isUnavailable(focal)
    };
  }
  function visibleTweets() {
    const out = [];
    for (const article of $$(SEL.article)) {
      const info = articleInfo(article);
      if (!info) continue;
      out.push({ ...info, liked: !!$(SEL.unlike, article), reposted: !!$(SEL.unretweet, article) });
    }
    return out;
  }
  async function scrollMore() {
    const ids = () => $$(SEL.article).map((a) => articleInfo(a)?.id).filter(Boolean);
    const before = new Set(ids());
    const last = $$(SEL.article).at(-1);
    last?.scrollIntoView({ block: "end" });
    window.scrollBy(0, Math.round(window.innerHeight * 0.75));
    await waitFor(() => ids().some((id) => !before.has(id)), 6e3);
    const now = ids();
    const scroller = document.scrollingElement ?? document.documentElement;
    const lowest = $$(SEL.article).at(-1);
    return {
      added: now.filter((id) => !before.has(id)).length,
      total: now.length,
      atEnd: scroller.scrollTop + window.innerHeight >= scroller.scrollHeight - 8,
      lastTime: lowest ? articleInfo(lowest)?.time ?? null : null
    };
  }
  async function clearPage() {
    const dialog = openDialog();
    if (!dialog) return { clear: true, what: "" };
    const what = describeDialog(dialog);
    const info = pageInfo();
    if (!info.loggedIn || info.locked || info.challenge) return { clear: false, what };
    const gone = () => !openDialog();
    closeMenus();
    if (await waitFor(gone, 1500)) return { clear: true, what };
    const close = $(SEL.dialogClose, openDialog() ?? document);
    if (close) {
      click(close);
      if (await waitFor(gone, 1500)) return { clear: true, what };
    }
    return { clear: false, what };
  }
  async function noMenuOpen() {
    if (!$(SEL.menu)) return true;
    closeMenus();
    return !!await waitFor(() => !$(SEL.menu), 2e3);
  }
  async function focus(article) {
    article.scrollIntoView({ block: "center" });
    await sleep(jitter(250, 600));
  }
  async function deletePost(id) {
    const article = findArticle(id);
    if (!article) return { outcome: "not_found", message: "Post is not on the page" };
    await focus(article);
    const caret = $(SEL.caret, article);
    if (!caret) return { outcome: "failed", message: "Post menu button not found" };
    if (!await noMenuOpen()) return { outcome: "failed", message: "Another menu is open on the X page" };
    click(caret);
    const item = await waitFor(() => $$(SEL.menu).length === 1 && findDeleteMenuItem(), 4e3);
    if (!item) {
      closeMenus();
      return { outcome: "failed", message: 'No "Delete" option \u2014 not your post, or X changed its menu' };
    }
    await sleep(jitter(150, 400));
    click(item);
    const confirm = await waitFor(() => $(SEL.confirm), 4e3);
    if (!confirm || !findArticle(id)) {
      closeMenus();
      return { outcome: "failed", message: "Delete confirmation did not appear for this post" };
    }
    const response = waitForNet(["DeleteTweet"], (v) => v.tweet_id === id);
    await sleep(jitter(150, 400));
    click(confirm);
    return classify(await response, "DeleteTweet");
  }
  async function unlike(id) {
    const article = findArticle(id);
    if (!article) return orUnavailable(id, { outcome: "not_found", message: "Post is not on the page" });
    await focus(article);
    const button = $(SEL.unlike, article);
    if (!button) {
      return $(SEL.like, article) ? { outcome: "already", message: 'X shows this post as not liked (a "ghost" like)' } : orUnavailable(id, { outcome: "failed", message: "Like button not found" });
    }
    const response = waitForNet(["UnfavoriteTweet"], (v) => v.tweet_id === id);
    click(button);
    return classify(await response, "UnfavoriteTweet");
  }
  async function relikeUnlike(id) {
    const article = findArticle(id);
    if (!article) return orUnavailable(id, { outcome: "not_found", message: "Post is not on the page" });
    await focus(article);
    if (!$(SEL.unlike, article)) {
      const like = $(SEL.like, article);
      if (!like) return orUnavailable(id, { outcome: "failed", message: "Like button not found" });
      const liked = waitForNet(["FavoriteTweet"], (v) => v.tweet_id === id);
      click(like);
      const result = classify(await liked, "FavoriteTweet");
      if (result.outcome !== "done" && result.outcome !== "already") return result;
      await sleep(jitter(1500, 3e3));
    }
    for (let attempt = 0; attempt < 3; attempt++) {
      const found = findArticle(id);
      if (found && await waitFor(() => $(SEL.unlike, found), 5e3)) {
        const result = await unlike(id);
        if (result.outcome !== "failed") return result;
      }
      await sleep(jitter(2e3, 4e3));
    }
    return {
      outcome: "failed",
      message: "Re-liked, but unliking failed \u2014 the post is still liked; run the cleanup again"
    };
  }
  async function unretweet(id) {
    const reposted = id ? [] : $$(SEL.article).filter((a) => $(SEL.unretweet, a));
    const article = id ? findArticle(id) : reposted.length === 1 ? reposted[0] : null;
    if (!article) return orUnavailable(id, { outcome: "not_found", message: "Post is not on the page" });
    await focus(article);
    const button = $(SEL.unretweet, article);
    if (!button) {
      return $(SEL.retweet, article) ? { outcome: "already", message: "Not reposted anymore" } : orUnavailable(id, { outcome: "failed", message: "Repost button not found" });
    }
    const sourceId = id || articleInfo(article)?.id || "";
    click(button);
    const confirm = await waitFor(() => $(SEL.unretweetConfirm), 4e3);
    if (!confirm) {
      closeMenus();
      return { outcome: "failed", message: "Undo-repost option did not appear" };
    }
    const response = waitForNet(["DeleteRetweet"], (v) => !sourceId || v.source_tweet_id === sourceId);
    await sleep(jitter(150, 400));
    click(confirm);
    return classify(await response, "DeleteRetweet");
  }
  var verdict = (v, message) => ({ verdict: v, message });
  async function canary(action, id) {
    const article = id ? findArticle(id) : null;
    if (!article) return verdict("unknown", "the post is not on the page");
    await focus(article);
    switch (action) {
      case "delete":
        return menuCheck(
          $(SEL.caret, article),
          () => $$(SEL.menu).length === 1 && findDeleteMenuItem(),
          "the post menu (\u2026)",
          "a Delete option"
        );
      case "unretweet":
        if (!$(SEL.unretweet, article)) {
          return $(SEL.retweet, article) ? verdict("unknown", "X shows this post as not reposted") : verdict("changed", "the repost button is missing from the post");
        }
        return menuCheck(
          $(SEL.unretweet, article),
          () => $(SEL.unretweetConfirm),
          "the repost menu",
          "an Undo repost option"
        );
      case "unlike":
      case "relike":
        if ($(SEL.unlike, article)) return verdict("ok", "the unlike button is where Xomoni expects it");
        if (!$(SEL.like, article)) return verdict("changed", "the like button is missing from the post");
        return action === "relike" ? verdict("ok", "the like button is where Xomoni expects it") : verdict("unknown", "X shows this post as not liked");
    }
  }
  async function menuCheck(button, probe, menu, option) {
    if (!button) return verdict("changed", `the button that opens ${menu} is missing`);
    if (!await noMenuOpen()) return verdict("changed", "a menu on the X page does not close");
    click(button);
    const found = await waitFor(probe, 4e3);
    await sleep(jitter(200, 500));
    const closed = await noMenuOpen();
    if (!found) return verdict("changed", `${menu} opened without ${option}`);
    if (!closed) return verdict("changed", "Escape no longer closes X\u2019s menu");
    return verdict("ok", `${option} is where Xomoni expects it`);
  }
  function classify(ev, op) {
    if (!ev) return { outcome: "failed", message: `X did not answer ${op} within 15s` };
    const resetAt = resetAtFrom(ev.headers, ev.at);
    if (ev.status === 429) return { outcome: "rate_limited", http: 429, resetAt, message: "Rate limit reached" };
    for (const { code, message } of extractErrors(ev.json)) {
      const base = { http: ev.status, code, message: message || `Error ${code}`, resetAt };
      switch (code) {
        case 88:
          return { ...base, outcome: "rate_limited" };
        case 185:
        case 344:
          return { ...base, outcome: "daily_limit" };
        case 226:
          return { ...base, outcome: "automation_flag" };
        case 64:
          return { ...base, outcome: "suspended" };
        case 326:
          return { ...base, outcome: "locked" };
        // Not permitted, write actions refused, credentials not allowed: X is limiting this account.
        case 87:
        case 220:
        case 261:
          return { ...base, outcome: "restricted" };
        case 32:
        case 89:
        case 215:
        case 353:
          return { ...base, outcome: "logged_out" };
        case 34:
        case 144:
          return { ...base, outcome: "not_found" };
        case 139:
        case 327:
          return { ...base, outcome: "already" };
        default:
          break;
      }
      return { ...base, outcome: ev.status === 403 ? "restricted" : "failed" };
    }
    if (ev.status === 403) return { outcome: "restricted", http: 403, message: "X refused the action (HTTP 403)" };
    if (ev.status >= 400 || ev.status === 0)
      return { outcome: "failed", http: ev.status, message: `X answered HTTP ${ev.status}` };
    return at(ev.json, "data") ? { outcome: "done", http: ev.status } : { outcome: "failed", http: ev.status, message: "Unexpected response" };
  }

  // src/content/content.ts
  var channel = new MessageChannel();
  channel.port1.onmessage = (event) => {
    if (isCapture(event.data)) handleCapture(event.data);
  };
  offerPort(document, channel.port2);
  function isActorMessage(message) {
    const m = asObject(message);
    return m?.type === "actor" && !!asObject(m.command);
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!isActorMessage(message)) return;
    runCommand(message.command).then(
      sendResponse,
      (err) => sendResponse({ error: err instanceof Error ? err.message : String(err) })
    );
    return true;
  });
})();
